Thank you for reading!  I hope you enjoy watching this routine as much as I enjoyed writing it!
Instructions:
1  Unzip RVW_JLD_[date].zip
2  Open RVW_FTC_challenge.c in ROBOTC
3  Set compiler target to Virtual Worlds
4  Compile and Download
5  Log in to Virtual Worlds as a guest
6  Click 'Single Player'
7  Use the following settings:
	Robot -		Gyro ScissorBot
	Game Mode -	CS2N Competition
	Start Point -	1
8  Click 'Start' and then >
9  Enjoy